package com.example.pengunjungku;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.*;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;

public class MainActivity extends AppCompatActivity {

    public TextView greetingTag, userName, statusTag, statusVal, visitorTag, visitorVal, capacityVal;
    public EditText setCapacityVal;
    public Button setCapacity;

    DatabaseReference mJumlahPengunjung, mKapasitasPengunjung, mStatus;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //db ref
        mJumlahPengunjung = FirebaseDatabase.getInstance().getReference("JumPengunjung");
        mKapasitasPengunjung = FirebaseDatabase.getInstance().getReference("MaxPengunjung");
        mStatus = FirebaseDatabase.getInstance().getReference("status");

        setCapacity = (Button) findViewById(R.id.setCapacity);
        setCapacityVal = (EditText) findViewById(R.id.setCapacityVal);

        greetingTag = (TextView) findViewById(R.id.greetingText);
        userName = (TextView) findViewById(R.id.userName);

        statusTag = (TextView) findViewById(R.id.statusTag);
        statusVal = (TextView) findViewById(R.id.statusVal);

        visitorTag = (TextView) findViewById(R.id.visitorTag);
        visitorVal = (TextView) findViewById(R.id.visitorVal);
        capacityVal = (TextView) findViewById(R.id.capacityVal);

        //set username and greetings
        userName.setText("Angelica");
        greetingTag.setText("Selamat Siang,");

        //update kapasitas pengunjung sesuai dgn db
        mKapasitasPengunjung.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if(snapshot.exists()){
                    String data = snapshot.getValue().toString();
                    capacityVal.setText(data);

                    Integer pengunjung = Integer.parseInt(visitorVal.getText().toString());
                    Integer capacity = Integer.parseInt(data);

                    //perubahan aman vs tidak & trigger nyala alarm
                    if(pengunjung > capacity){

                        statusVal.setText("TIDAK AMAN");
                        //TRIGGER ALARM
                        notification();
                        mStatus.setValue(1);




                    } else {
                        statusVal.setText("AMAN");
                        mStatus.setValue(0);
                    }

                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });

        //update jumlah pengunjung sesuai dgn db
        mJumlahPengunjung.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if(snapshot.exists()){
                    String data = snapshot.getValue().toString();
                    visitorVal.setText(data);

                    Integer pengunjung = Integer.parseInt(data);
                    Integer capacity = Integer.parseInt(capacityVal.getText().toString());

                    //perubahan aman vs tidak & trigger nyala alarm
                    if(pengunjung > capacity){

                        statusVal.setText("TIDAK AMAN");
                        //TRIGGER ALARM
                        notification();
                        mStatus.setValue(1);


                    } else {
                        statusVal.setText("AMAN");
                        mStatus.setValue(0);
                    }

                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });



        //update db kapasitas pengunjung terbaru
        setCapacity.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Integer pengunjung = Integer.parseInt(visitorVal.getText().toString());
                Integer setCapacity = Integer.parseInt(setCapacityVal.getText().toString());
                if(setCapacity > pengunjung) {
                    mKapasitasPengunjung.setValue(setCapacityVal.getText().toString());
                } else {
                    Toast toast = Toast.makeText(getApplicationContext(),
                            "Kapasitas harus melebihi jumlah pengunjung saat ini",
                            Toast.LENGTH_SHORT);

                    toast.show();
                }

            }
        });




    }

private void notification(){
        if(Build.VERSION.SDK_INT >=Build.VERSION_CODES.O){
            NotificationChannel channel =
                    new NotificationChannel("n", "n", NotificationManager.IMPORTANCE_HIGH);
            NotificationManager manager = getSystemService(NotificationManager.class);
            manager.createNotificationChannel(channel);
        }

    NotificationCompat.Builder builder = new NotificationCompat.Builder(this, "n")
            .setContentText("content text")
            .setSmallIcon(R.drawable.ic_baseline_notifications_24)
            .setAutoCancel(true)
            .setContentText("Pengunjung telah melebihi kapasitas!");

    NotificationManagerCompat managerCompat = NotificationManagerCompat.from(this);
    managerCompat.notify(99, builder.build());
}

}